// DeepSeek网站特定修复脚本

// 等待页面完全加载
window.addEventListener('load', function() {
  // 确认是否在DeepSeek网站上
  if (window.location.hostname.includes('deepseek.com') || 
      window.location.hostname.includes('deepseek.ai') || 
      window.location.hostname.includes('chat.deepseek.com') || 
      window.location.hostname.includes('chat.deepseek.ai') || 
      window.location.hostname.includes('deepseek.chat')) {
    
    console.log('DeepSeek网站检测到，启动特定修复脚本');
    
    // 延迟执行，确保DeepSeek的UI完全加载
    setTimeout(setupDeepSeekListeners, 2000);
    
    // 定期检查并设置监听器，处理动态加载的元素
    setInterval(setupDeepSeekListeners, 5000);
  }
});

// 设置DeepSeek特定的监听器
function setupDeepSeekListeners() {
  console.log('设置DeepSeek特定监听器...');
  
  // 更全面的DeepSeek输入框选择器
  const deepseekSelectors = [
    // 基本选择器
    '.chat-input-box textarea',
    '.chat-input-panel textarea',
    '.chat-input-area textarea',
    '.chat-input-container textarea',
    '.message-input textarea',
    '.editor-wrapper textarea',
    '.chat-message-input textarea',
    '.chat-input-wrapper textarea',
    
    // 可编辑div选择器
    '.chat-input-box [contenteditable="true"]',
    '.chat-input-panel [contenteditable="true"]',
    '.chat-input-area [contenteditable="true"]',
    '.chat-input-container [contenteditable="true"]',
    '.message-input [contenteditable="true"]',
    '.editor-wrapper [contenteditable="true"]',
    '.chat-message-input [contenteditable="true"]',
    '.chat-input-wrapper [contenteditable="true"]',
    
    // 角色选择器
    '[role="textbox"]',
    '[data-slate-editor="true"]',
    
    // 类名选择器
    '[class*="deepseek"] textarea',
    '[class*="deepseek"] [contenteditable="true"]',
    '[class*="deepseek"] [role="textbox"]',
    '[class*="chat-input"] textarea',
    '[class*="chat-input"] [contenteditable="true"]',
    '[class*="chat-input"] [role="textbox"]',
    '[class*="editor"] textarea',
    '[class*="editor"] [contenteditable="true"]',
    '[class*="editor"] [role="textbox"]',
    
    // 特定占位符选择器
    'textarea[placeholder*="Ask DeepSeek"]',
    'textarea[placeholder*="问DeepSeek"]',
    'textarea[placeholder*="与DeepSeek聊天"]',
    'textarea[placeholder*="Chat with DeepSeek"]',
    'textarea[placeholder*="发送信息"]',
    'textarea[placeholder*="Send a message"]',
    
    // 通用聊天输入框
    'textarea[placeholder*="chat"]',
    'textarea[placeholder*="聊天"]',
    'textarea[placeholder*="对话"]',
    'textarea[placeholder*="提问"]',
    'textarea[placeholder*="问题"]'
  ];
  
  // 合并所有选择器
  const allSelectors = deepseekSelectors.join(', ');
  
  // 查找所有匹配的输入元素
  const inputElements = document.querySelectorAll(allSelectors);
  console.log('找到DeepSeek输入元素数量:', inputElements.length);
  
  // 输出找到的元素详细信息，帮助调试
  inputElements.forEach((input, index) => {
    console.log(`DeepSeek输入元素 #${index}:`, {
      tagName: input.tagName,
      type: input.type,
      id: input.id,
      class: input.className,
      placeholder: input.placeholder,
      contentEditable: input.getAttribute('contenteditable'),
      role: input.getAttribute('role'),
      parentNode: input.parentNode ? input.parentNode.tagName : 'none',
      parentClass: input.parentNode ? input.parentNode.className : 'none'
    });
  });
  
  // 为每个输入元素添加事件监听器
  inputElements.forEach(input => {
    // 避免重复添加监听器
    if (input.dataset.deepseekMonitored) return;
    
    // 标记为已监听
    input.dataset.deepseekMonitored = 'true';
    console.log('为DeepSeek输入元素添加监听器:', input);
    
    // 监听键盘事件，捕获各种提交组合键
    input.addEventListener('keydown', function(e) {
      // 获取输入内容
      let inputContent = '';
      if (input.tagName.toLowerCase() === 'textarea') {
        inputContent = input.value.trim();
      } else {
        inputContent = (input.textContent || input.innerText || '').trim();
      }
      
      console.log('DeepSeek键盘事件:', e.key, '输入值:', inputContent);
      
      // 捕获常见的提交快捷键组合
      const isEnterSubmit = e.key === 'Enter' && !e.shiftKey;
      const isCtrlEnterSubmit = e.key === 'Enter' && e.ctrlKey;
      const isMetaEnterSubmit = e.key === 'Enter' && e.metaKey; // Mac上的Command+Enter
      
      if ((isEnterSubmit || isCtrlEnterSubmit || isMetaEnterSubmit) && inputContent) {
        console.log('DeepSeek输入框提交捕获到输入:', inputContent);
        saveInputToBackground(inputContent, 'DeepSeek输入框提交');
      }
    });
    
    // 监听失去焦点事件
    input.addEventListener('blur', function() {
      let inputContent = '';
      if (input.tagName.toLowerCase() === 'textarea') {
        inputContent = input.value.trim();
      } else {
        inputContent = (input.textContent || input.innerText || '').trim();
      }
      
      if (inputContent) {
        console.log('DeepSeek输入框失焦捕获到输入:', inputContent);
        saveInputToBackground(inputContent, 'DeepSeek输入框失焦');
      }
    });
  });
  
  // 查找并监听提交按钮
  const submitButtonSelectors = [
    'button[type="submit"]',
    'button[aria-label*="发送"]',
    'button[aria-label*="Send"]',
    'button[aria-label*="提交"]',
    'button[aria-label*="Submit"]',
    '[class*="send-button"]',
    '[class*="submit-button"]',
    '[class*="send-icon"]',
    '[class*="submit-icon"]',
    'svg[class*="send"]',
    'svg[class*="submit"]',
    '[role="button"][aria-label*="发送"]',
    '[role="button"][aria-label*="Send"]'
  ];
  
  const allButtonSelectors = submitButtonSelectors.join(', ');
  const submitButtons = document.querySelectorAll(allButtonSelectors);
  
  console.log('找到DeepSeek提交按钮数量:', submitButtons.length);
  
  submitButtons.forEach((button, index) => {
    // 避免重复添加监听器
    if (button.dataset.deepseekButtonMonitored) return;
    
    // 标记为已监听
    button.dataset.deepseekButtonMonitored = 'true';
    console.log(`DeepSeek提交按钮 #${index}:`, button);
    
    button.addEventListener('click', function() {
      // 查找相关联的输入框
      const container = button.closest('.chat-input-box, .chat-input-panel, .chat-input-area, .chat-input-container, .message-input, .editor-wrapper, .chat-message-input, .chat-input-wrapper, [class*="chat-input"], [class*="message-input"], [class*="editor"]');
      
      if (container) {
        const associatedInputs = container.querySelectorAll(allSelectors);
        
        associatedInputs.forEach(input => {
          let inputContent = '';
          if (input.tagName.toLowerCase() === 'textarea') {
            inputContent = input.value.trim();
          } else {
            inputContent = (input.textContent || input.innerText || '').trim();
          }
          
          if (inputContent) {
            console.log('DeepSeek按钮点击捕获到输入:', inputContent);
            saveInputToBackground(inputContent, 'DeepSeek按钮点击');
          }
        });
      } else {
        // 如果找不到容器，尝试查找页面上所有输入框
        const allInputs = document.querySelectorAll(allSelectors);
        
        allInputs.forEach(input => {
          let inputContent = '';
          if (input.tagName.toLowerCase() === 'textarea') {
            inputContent = input.value.trim();
          } else {
            inputContent = (input.textContent || input.innerText || '').trim();
          }
          
          if (inputContent) {
            console.log('DeepSeek按钮点击(全局搜索)捕获到输入:', inputContent);
            saveInputToBackground(inputContent, 'DeepSeek按钮点击(全局)');
          }
        });
      }
    });
  });
  
  // 尝试处理Shadow DOM
  try {
    const potentialShadowHosts = document.querySelectorAll('[class*="deepseek"], [class*="chat"], [class*="editor"], [class*="input"]');
    
    potentialShadowHosts.forEach(host => {
      if (host.shadowRoot) {
        console.log('找到DeepSeek Shadow DOM:', host);
        
        // 在Shadow DOM中查找输入元素
        const shadowInputs = host.shadowRoot.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"], [data-slate-editor="true"]');
        console.log('在Shadow DOM中找到输入元素数量:', shadowInputs.length);
        
        // 为Shadow DOM中的输入元素添加监听器
        shadowInputs.forEach((input, index) => {
          if (input.dataset.deepseekShadowMonitored) return;
          
          input.dataset.deepseekShadowMonitored = 'true';
          console.log(`Shadow DOM输入元素 #${index}:`, input);
          
          // 添加与普通元素相同的事件监听器
          input.addEventListener('keydown', function(e) {
            let inputContent = '';
            if (input.tagName.toLowerCase() === 'textarea') {
              inputContent = input.value.trim();
            } else {
              inputContent = (input.textContent || input.innerText || '').trim();
            }
            
            const isEnterSubmit = e.key === 'Enter' && !e.shiftKey;
            const isCtrlEnterSubmit = e.key === 'Enter' && e.ctrlKey;
            const isMetaEnterSubmit = e.key === 'Enter' && e.metaKey;
            
            if ((isEnterSubmit || isCtrlEnterSubmit || isMetaEnterSubmit) && inputContent) {
              console.log('Shadow DOM输入框提交捕获到输入:', inputContent);
              saveInputToBackground(inputContent, 'DeepSeek Shadow DOM提交');
            }
          });
          
          input.addEventListener('blur', function() {
            let inputContent = '';
            if (input.tagName.toLowerCase() === 'textarea') {
              inputContent = input.value.trim();
            } else {
              inputContent = (input.textContent || input.innerText || '').trim();
            }
            
            if (inputContent) {
              console.log('Shadow DOM输入框失焦捕获到输入:', inputContent);
              saveInputToBackground(inputContent, 'DeepSeek Shadow DOM失焦');
            }
          });
        });
      }
    });
  } catch (error) {
    console.warn('尝试访问Shadow DOM时出错:', error);
  }
}

// 保存输入到背景脚本
function saveInputToBackground(text, source) {
  try {
    // 参数验证
    if (!text || typeof text !== 'string' || text.length < 2) {
      console.log('输入文本无效或太短，已忽略');
      return;
    }
    
    // 检查是否包含密码关键词
    const passwordKeywords = ['password', 'pwd', 'passwd', 'passphrase', '密码', 'passwort', 'contraseña'];
    const lowerText = text.toLowerCase();
    for (const keyword of passwordKeywords) {
      if (lowerText.includes(keyword)) {
        console.log('检测到可能的密码内容，已阻止保存');
        return;
      }
    }
    
    // 确保source参数有效
    source = source || '未知来源';
    if (typeof source !== 'string') {
      console.warn('无效的来源类型，使用默认值');
      source = '未知来源';
    }
    
    // 安全获取URL和标题
    let currentUrl = '';
    let currentTitle = '';
    
    try {
      currentUrl = window.location.href || '';
    } catch (urlError) {
      console.warn('获取当前URL时出错:', urlError);
      currentUrl = '';
    }
    
    try {
      currentTitle = document.title || '';
    } catch (titleError) {
      console.warn('获取页面标题时出错:', titleError);
      currentTitle = '';
    }
    
    console.log('DeepSeek特定脚本尝试保存输入:', text, '来源:', source);
    
    // 安全检查：确保chrome.runtime存在
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      try {
        // 发送消息到背景脚本
        chrome.runtime.sendMessage({
          action: 'saveInput',
          data: {
            text: text,
            url: currentUrl,
            title: currentTitle,
            source: source + ' (DeepSeek特定脚本)',
            timestamp: Date.now()
          }
        }, function(response) {
          if (response && response.status === 'success') {
            console.log('DeepSeek输入已成功保存');
          } else {
            console.warn('保存DeepSeek输入失败:', response ? response.message : '未知错误');
          }
        });
      } catch (sendError) {
        console.error('发送消息时发生错误:', sendError);
      }
    } else {
      console.error('发送消息时发生错误: chrome.runtime 未定义或不可用');
    }
  } catch (error) {
    console.error('保存DeepSeek输入时发生错误:', error);
  }
}